var searchData=
[
  ['caps_5fpin_5fid_0',['CAPS_pin_id',['../system_8h.html#ab1c06178fe17463de7febff8ab12afc9',1,'system.h']]],
  ['caps_5fport_1',['CAPS_port',['../system_8h.html#af4b8f99cff7d21496fbef349b94218f9',1,'system.h']]],
  ['cdc_5fonly_5fon_5fusb_2',['CDC_ONLY_ON_USB',['../system_8h.html#aa7c24ce55e6f563ec2e802f127009892',1,'system.h']]],
  ['check_5fxonxoff_5fsendnow_5fclose_5fbracket_3',['CHECK_XONXOFF_SENDNOW_CLOSE_BRACKET',['../system_8h.html#a26fe0d98327b848fede4b8104a11cfb2',1,'system.h']]],
  ['check_5fxonxoff_5fsendnow_5fstart_5fwith_5fopen_5fbracket_4',['CHECK_XONXOFF_SENDNOW_START_WITH_OPEN_BRACKET',['../system_8h.html#aaa1befa2f4cd31d8c356ef6ca4d109f1',1,'system.h']]],
  ['comm_5fpacket_5fsize_5',['COMM_PACKET_SIZE',['../system_8h.html#a43c08afbbaf9e8a3a694a4fe98a79e10',1,'system.h']]],
  ['con_5frx_5fring_5fbuffer_5fsize_6',['CON_RX_RING_BUFFER_SIZE',['../system_8h.html#afb68747ca6ab20c95bce4ff30c30e854',1,'system.h']]],
  ['con_5ftx_5fring_5fbuffer_5fsize_7',['CON_TX_RING_BUFFER_SIZE',['../system_8h.html#a0a0043e9c1f4a50711f735787aa79ad1',1,'system.h']]]
];
