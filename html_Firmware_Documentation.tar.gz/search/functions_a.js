var searchData=
[
  ['tim_5fhr_5fsetup_0',['tim_hr_setup',['../hr__timer_8c.html#a8ae961e30b547238f645ad27ec6f5b85',1,'tim_hr_setup(uint32_t timer_peripheral):&#160;hr_timer.c'],['../hr__timer_8h.html#a8ae961e30b547238f645ad27ec6f5b85',1,'tim_hr_setup(uint32_t timer_peripheral):&#160;hr_timer.c']]]
];
