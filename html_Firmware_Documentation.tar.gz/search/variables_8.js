var searchData=
[
  ['last_5fdma_5ftx_5fset_5fnumber_5fof_5fdata_0',['last_dma_tx_set_number_of_data',['../serial_8c.html#ae62f7ed40c2ec6f8acf6dec2cd8f93c9',1,'serial.c']]],
  ['last_5fps2_5ffails_1',['last_ps2_fails',['../sys__timer_8cpp.html#a0ff02cb4b1b7550eeef0c519f3c9dbf1',1,'sys_timer.cpp']]]
];
