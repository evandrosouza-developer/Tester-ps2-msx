var searchData=
[
  ['base_5fring_5fbuffer_5fsize_0',['BASE_RING_BUFFER_SIZE',['../system_8h.html#aaa991f7d0fe0a15baf96c8988bfcd564',1,'system.h']]],
  ['base_5fring_5fbuffer_5fsize_5fpower_1',['BASE_RING_BUFFER_SIZE_POWER',['../system_8h.html#a835579e872d02af9807844c9d394a160',1,'system.h']]],
  ['board_5fident_2',['BOARD_IDENT',['../usb__descriptors_8h.html#a209aaee6e9cf4f39cb1f575819284e6e',1,'usb_descriptors.h']]]
];
