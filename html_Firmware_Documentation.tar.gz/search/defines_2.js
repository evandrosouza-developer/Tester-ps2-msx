var searchData=
[
  ['delay_5fto_5fread_5fsize_0',['DELAY_TO_READ_SIZE',['../system_8h.html#ae4fa43809e1354c6f369bb95e96ce236',1,'system.h']]],
  ['desig_5funiq_5fid_5fbase_1',['DESIG_UNIQ_ID_BASE',['../system_8h.html#aa10a9d43f0c47a66551fdf624acbab78',1,'system.h']]],
  ['dma_5fcgif_2',['DMA_CGIF',['../system_8h.html#ad74e3be71ee606943395eebb788ec3b8',1,'system.h']]],
  ['dma_5fch_5freset_3',['dma_ch_reset',['../system_8h.html#a3244fa4889720b9196778a72879a7353',1,'system.h']]],
  ['dma_5fcr_4',['DMA_CR',['../system_8h.html#acfc38bcb982272f5eaf2b00932f9a68e',1,'system.h']]],
  ['dma_5fcr_5fen_5',['DMA_CR_EN',['../system_8h.html#aba51b356c057ba363c73bfabf63a0f57',1,'system.h']]],
  ['dma_5fdisable_5fch_6',['dma_disable_ch',['../system_8h.html#ac9a1c220d89f26ec64c1528809126264',1,'system.h']]],
  ['dma_5fenable_5fch_7',['dma_enable_ch',['../system_8h.html#a9e59a8031d48040d0758ac39a32f9c2c',1,'system.h']]],
  ['dma_5fmsize_5f8bit_8',['DMA_MSIZE_8BIT',['../system_8h.html#aa27b9caef4846745fa45894e8007c3f0',1,'system.h']]],
  ['dma_5fpl_5fhigh_9',['DMA_PL_HIGH',['../system_8h.html#a91d7de41b951283a2fade8066e8fca16',1,'system.h']]],
  ['dma_5fpsize_5f8bit_10',['DMA_PSIZE_8BIT',['../system_8h.html#a4a86265f407e23d295acfbf6265c66b4',1,'system.h']]]
];
