var searchData=
[
  ['kana_5fline_0',['kana_line',['../sys__timer_8cpp.html#a68bd9f3753ad46dc36071e83eb5b31af',1,'kana_line():&#160;sys_timer.cpp'],['../tester-ps2-msx_8cpp.html#a68bd9f3753ad46dc36071e83eb5b31af',1,'kana_line():&#160;tester-ps2-msx.cpp']]],
  ['kana_5fpin_5fid_1',['KANA_pin_id',['../system_8h.html#aaa3346d0d00a37c9afe94b2e2b7b32db',1,'system.h']]],
  ['kana_5fport_2',['KANA_port',['../system_8h.html#a99baa32ec1aa3386251c8d4627e6ea80',1,'system.h']]]
];
