var searchData=
[
  ['hardware_5fbase_0',['HARDWARE_BASE',['../system_8h.html#a3677534aaa27607c8c7c13a818d9403d',1,'system.h']]],
  ['high_5fresolution_5ftimer_1',['High_Resolution_Timer',['../group__High__Resolution__Timer.html',1,'(Global Namespace)'],['../group__hr__timer.html',1,'(Global Namespace)']]],
  ['hr_5ftimer_2ec_2',['hr_timer.c',['../hr__timer_8c.html',1,'']]],
  ['hr_5ftimer_2eh_3',['hr_timer.h',['../hr__timer_8h.html',1,'']]]
];
