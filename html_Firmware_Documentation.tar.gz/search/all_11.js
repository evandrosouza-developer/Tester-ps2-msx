var searchData=
[
  ['rcc_5fdma_0',['RCC_DMA',['../system_8h.html#ae5b2be292c947583043983459d258efe',1,'RCC_DMA():&#160;system.h'],['../system_8h.html#ae5b2be292c947583043983459d258efe',1,'RCC_DMA():&#160;system.h'],['../system_8h.html#ae5b2be292c947583043983459d258efe',1,'RCC_DMA():&#160;system.h']]],
  ['rcc_5ftim_5fhr_1',['RCC_TIM_HR',['../system_8h.html#a24f8ea4fecdd702df15ec063fef1d60a',1,'system.h']]],
  ['rcc_5fusart_2',['RCC_USART',['../system_8h.html#ab4d980c69f61203986fbf894815a3875',1,'RCC_USART():&#160;system.h'],['../system_8h.html#ab4d980c69f61203986fbf894815a3875',1,'RCC_USART():&#160;system.h']]],
  ['read_5fserial_5fnumber_3',['Read_Serial_Number',['../group__serial__no.html',1,'']]],
  ['readme_2emd_4',['README.md',['../README_8md.html',1,'']]],
  ['readtimer_5',['readtimer',['../hr__timer_8c.html#a40c5ef7e820184dbaa548d5c38f0d4ea',1,'hr_timer.c']]],
  ['ring_5favail_5fget_5fch_6',['ring_avail_get_ch',['../serial_8c.html#afcaa76e9618a9ea44893a7b4ea642380',1,'ring_avail_get_ch(struct sring *ring):&#160;serial.c'],['../serial_8h.html#afcaa76e9618a9ea44893a7b4ea642380',1,'ring_avail_get_ch(struct sring *ring):&#160;serial.c']]],
  ['ring_5fget_5fch_7',['ring_get_ch',['../serial_8c.html#ac8cb0719d8742a1c76a554fd9b9874ec',1,'ring_get_ch(struct sring *ring, uint16_t *qty_in_buffer):&#160;serial.c'],['../serial_8h.html#ac8cb0719d8742a1c76a554fd9b9874ec',1,'ring_get_ch(struct sring *ring, uint16_t *qty_in_buffer):&#160;serial.c']]],
  ['ring_5finit_8',['ring_init',['../serial_8c.html#a9e25311a663dda3a933f14bfd7beb6a8',1,'ring_init(struct sring *ring, uint8_t *buf, uint16_t buffer_size):&#160;serial.c'],['../serial_8h.html#a9e25311a663dda3a933f14bfd7beb6a8',1,'ring_init(struct sring *ring, uint8_t *buf, uint16_t buffer_size):&#160;serial.c']]],
  ['ring_5fput_5fch_9',['ring_put_ch',['../serial_8c.html#a07469dc6c9ef0cb391bff88443f82d98',1,'ring_put_ch(struct sring *ring, uint8_t ch):&#160;serial.c'],['../serial_8h.html#a07469dc6c9ef0cb391bff88443f82d98',1,'ring_put_ch(struct sring *ring, uint8_t ch):&#160;serial.c']]],
  ['rst_5ftim_5fhr_10',['RST_TIM_HR',['../system_8h.html#a8df28c83024ffa7d0dfab5ea8afae117',1,'system.h']]],
  ['rx_5fdma_5fsize_11',['RX_DMA_SIZE',['../system_8h.html#a5f3f1d441a162fee57146836a3711ea3',1,'system.h']]]
];
