var searchData=
[
  ['inactivity_5fcycles_0',['inactivity_cycles',['../sys__timer_8cpp.html#a6262d7a2d5ddbac552c00dce9884c4e0',1,'inactivity_cycles():&#160;sys_timer.cpp'],['../t__msxmap_8cpp.html#a6262d7a2d5ddbac552c00dce9884c4e0',1,'inactivity_cycles():&#160;sys_timer.cpp'],['../tester-ps2-msx_8cpp.html#a6262d7a2d5ddbac552c00dce9884c4e0',1,'inactivity_cycles():&#160;sys_timer.cpp']]],
  ['init_5finactivity_5fcycles_1',['init_inactivity_cycles',['../t__msxmap_8cpp.html#abc022f863c96fe6c58b2f1f0ef6febf4',1,'init_inactivity_cycles():&#160;tester-ps2-msx.cpp'],['../tester-ps2-msx_8cpp.html#abc022f863c96fe6c58b2f1f0ef6febf4',1,'init_inactivity_cycles():&#160;tester-ps2-msx.cpp']]],
  ['init_5fscancount_2',['init_scancount',['../sys__timer_8cpp.html#ab59906e5c4dd5a337ee471ffc41ed628',1,'init_scancount():&#160;sys_timer.cpp'],['../t__msxmap_8cpp.html#a9d2e84a24e17751c9028d77161b24ae6',1,'init_scancount():&#160;sys_timer.cpp'],['../tester-ps2-msx_8cpp.html#a9d2e84a24e17751c9028d77161b24ae6',1,'init_scancount():&#160;sys_timer.cpp']]]
];
