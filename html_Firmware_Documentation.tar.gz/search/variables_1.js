var searchData=
[
  ['buf_5fdma_5frx_0',['buf_dma_rx',['../serial_8c.html#af02d9f5207c626b542d5e8c6423e73e7',1,'serial.c']]],
  ['bufszmask_1',['bufSzMask',['../structs__pascal__string.html#a0b5b7a3d67ef63f72e764fbd6ac36297',1,'s_pascal_string::bufSzMask()'],['../structsring.html#a644560aad45670bb7554bd47af34aacb',1,'sring::bufSzMask()']]]
];
