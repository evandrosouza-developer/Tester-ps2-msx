var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxy",
  1: "ms",
  2: "chrstuv",
  3: "_cdfgimprstu",
  4: "abcdegiklmnoprstuwxy",
  5: "eit",
  6: "eist",
  7: "bcdefghiklmnoqrstuxy",
  8: "hmrstu",
  9: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Modules",
  9: "Pages"
};

