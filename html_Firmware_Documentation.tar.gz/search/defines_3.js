var searchData=
[
  ['embedded_5fled_5fpin_0',['EMBEDDED_LED_pin',['../system_8h.html#a896a502cfc6e155ccb459682edf7baa2',1,'system.h']]],
  ['embedded_5fled_5fport_1',['EMBEDDED_LED_port',['../system_8h.html#ab19708b536724c213aa7efb38f7cc0e4',1,'system.h']]]
];
