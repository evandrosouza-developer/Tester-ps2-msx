var searchData=
[
  ['max_5fusb_5fpacket_5fsize_0',['MAX_USB_PACKET_SIZE',['../system_8h.html#abf4ff0d649f6e7c0f3c4b37c7213d440',1,'system.h']]],
  ['mcu_1',['MCU',['../system_8h.html#abc4b095ebbdda642ee350f8e4ec0a994',1,'system.h']]],
  ['mntstr_5fsize_2',['MNTSTR_SIZE',['../system_8h.html#a8be881a613eeda9b2886a0441879d0c0',1,'system.h']]]
];
