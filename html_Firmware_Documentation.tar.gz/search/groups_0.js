var searchData=
[
  ['high_5fresolution_5ftimer_0',['High_Resolution_Timer',['../group__High__Resolution__Timer.html',1,'(Global Namespace)'],['../group__hr__timer.html',1,'(Global Namespace)']]]
];
