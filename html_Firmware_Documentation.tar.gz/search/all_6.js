var searchData=
[
  ['firmware_5fversion_0',['FIRMWARE_VERSION',['../version_8h.html#aa14dc39d52ab121ceb570f1a265385e0',1,'version.h']]],
  ['first_5fput_5fring_5fcontent_5fonto_5fep_1',['first_put_ring_content_onto_ep',['../cdcacm_8h.html#a775a23131d52c5bc13ff354e9de08570',1,'cdcacm.h']]]
];
