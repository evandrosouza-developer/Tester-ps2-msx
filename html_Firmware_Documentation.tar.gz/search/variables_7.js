var searchData=
[
  ['kana_5fline_0',['kana_line',['../sys__timer_8cpp.html#a68bd9f3753ad46dc36071e83eb5b31af',1,'kana_line():&#160;sys_timer.cpp'],['../tester-ps2-msx_8cpp.html#a68bd9f3753ad46dc36071e83eb5b31af',1,'kana_line():&#160;tester-ps2-msx.cpp']]]
];
