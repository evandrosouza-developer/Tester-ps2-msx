var searchData=
[
  ['general_5fdebug_5fsetup_0',['general_debug_setup',['../classmsxmap.html#a5b428f0a19a4cba4334f2982550bbd85',1,'msxmap']]]
];
