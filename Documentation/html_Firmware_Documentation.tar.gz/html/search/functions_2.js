var searchData=
[
  ['delay_5fqusec_0',['delay_qusec',['../hr__timer_8c.html#a8e95b556b883da169c180479d71e7246',1,'delay_qusec(uint32_t timer_peripheral, uint16_t qusec, void next_step(void)):&#160;hr_timer.c'],['../hr__timer_8h.html#a8e95b556b883da169c180479d71e7246',1,'delay_qusec(uint32_t timer_peripheral, uint16_t qusec, void next_step(void)):&#160;hr_timer.c']]],
  ['disable_5fusb_1',['disable_usb',['../cdcacm_8h.html#aece69c760bceda278c8c8fce8fcc38d2',1,'cdcacm.h']]],
  ['do_5fdma_5fusart_5ftx_5fring_2',['do_dma_usart_tx_ring',['../serial_8c.html#a0602b71dae2f607437c0ef26fd4cc19b',1,'do_dma_usart_tx_ring(uint16_t number_of_data):&#160;serial.c'],['../serial_8h.html#a0602b71dae2f607437c0ef26fd4cc19b',1,'do_dma_usart_tx_ring(uint16_t number_of_data):&#160;serial.c']]]
];
