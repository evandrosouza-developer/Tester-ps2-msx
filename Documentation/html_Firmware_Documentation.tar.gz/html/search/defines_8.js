var searchData=
[
  ['kana_5fpin_5fid_0',['KANA_pin_id',['../system_8h.html#aaa3346d0d00a37c9afe94b2e2b7b32db',1,'system.h']]],
  ['kana_5fport_1',['KANA_port',['../system_8h.html#a99baa32ec1aa3386251c8d4627e6ea80',1,'system.h']]]
];
