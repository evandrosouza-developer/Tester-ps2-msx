var searchData=
[
  ['next_5froutine_0',['next_routine',['../hr__timer_8c.html#a9c3dbc3640848430ae1334b71aeee31d',1,'hr_timer.c']]],
  ['nvic_5ftim_5fhr_5firq_1',['NVIC_TIM_HR_IRQ',['../system_8h.html#af95e448eca350b38d427a9c9237ac1d2',1,'system.h']]],
  ['nvic_5fusart_5firq_2',['NVIC_USART_IRQ',['../system_8h.html#aff25a818ad4471ca2f2100ba4458e24d',1,'NVIC_USART_IRQ():&#160;system.h'],['../system_8h.html#aff25a818ad4471ca2f2100ba4458e24d',1,'NVIC_USART_IRQ():&#160;system.h']]]
];
