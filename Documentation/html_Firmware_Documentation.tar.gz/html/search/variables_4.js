var searchData=
[
  ['enable_5fxon_5fxoff_0',['enable_xon_xoff',['../cdcacm_8c.html#a64d290bb0f3206115b1db9398859c634',1,'enable_xon_xoff():&#160;serial.c'],['../serial_8c.html#a64d290bb0f3206115b1db9398859c634',1,'enable_xon_xoff():&#160;serial.c']]]
];
