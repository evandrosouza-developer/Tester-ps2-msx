var searchData=
[
  ['pascal_5fstring_5finit_0',['pascal_string_init',['../serial_8c.html#a98aa51196c9b62456daf7a62998d1168',1,'pascal_string_init(struct s_pascal_string *ring, uint8_t *buf, uint8_t bufsize):&#160;serial.c'],['../serial_8h.html#a98aa51196c9b62456daf7a62998d1168',1,'pascal_string_init(struct s_pascal_string *ring, uint8_t *buf, uint8_t bufsize):&#160;serial.c']]],
  ['portxread_1',['portXread',['../t__msxmap_8cpp.html#a99eda0e079fbc2f46e5f91bcb067baab',1,'portXread(void):&#160;t_msxmap.cpp'],['../t__msxmap_8h.html#a99eda0e079fbc2f46e5f91bcb067baab',1,'portXread(void):&#160;t_msxmap.cpp']]],
  ['prepares_5fcapture_2',['prepares_capture',['../hr__timer_8c.html#aff0a7dc5d67649581348027ef501e3a7',1,'prepares_capture(uint32_t timer_peripheral):&#160;hr_timer.c'],['../hr__timer_8h.html#aff0a7dc5d67649581348027ef501e3a7',1,'prepares_capture(uint32_t timer_peripheral):&#160;hr_timer.c']]]
];
