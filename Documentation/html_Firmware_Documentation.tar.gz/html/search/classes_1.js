var searchData=
[
  ['s_5fpascal_5fstring_0',['s_pascal_string',['../structs__pascal__string.html',1,'']]],
  ['sring_1',['sring',['../structsring.html',1,'']]]
];
